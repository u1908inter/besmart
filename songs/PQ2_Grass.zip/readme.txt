ピコーン・クエスト2 草原
出典: ピコーン・クエスト2 (https://u1908inter.github.io/pikon-quest2/) のBGM
BGM: AI生成楽曲（非商用利用に限り可）
譜面: 自動生成 (NORMAL / HYPER, 7鍵)
曲の終わりはフェードアウトに加工しています
